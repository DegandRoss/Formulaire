const formTitle = document.getElementById('form-title');
const authForm = document.getElementById('auth-form');
const authEmail = document.getElementById('auth-email');
const authPassword = document.getElementById('auth-password');
const passwordStrength = document.getElementById('password-strength');
const errorMessage = document.getElementById('error-message');
const switchFormBtn = document.getElementById('switch-form');
let isRegistering = false;
let userData = {};

// Pour basculer entre Connexion et Inscription
switchFormBtn.addEventListener('click', () => {
    isRegistering = !isRegistering;
    formTitle.textContent = isRegistering ? 'Inscription' : 'Connexion';
    authForm.querySelector('button').textContent = isRegistering ? "S'inscrire" : "Se connecter";
    switchFormBtn.textContent = isRegistering ? "Se connecter" : "S'inscrire";
    passwordStrength.classList.toggle('hidden', !isRegistering);
    errorMessage.classList.add('hidden');
});

// Vérification de la force du mot de passe
authPassword.addEventListener('input', function () {
    if (!isRegistering) return;
    
    const password = this.value;
    let strength = "Faible";
    let color = "red";

    if (password.length >= 8 && /[A-Z]/.test(password) && /[0-9]/.test(password) && /[!@#$%^&*]/.test(password)) {
        strength = "Fort";
        color = "green";
    } else if (password.length >= 6 && (/[A-Z]/.test(password) || /[0-9]/.test(password))) {
        strength = "Moyen";
        color = "orange";
    }

    passwordStrength.textContent = `Force: ${strength}`;
    passwordStrength.style.color = color;
});

// Soumission du formulaire
authForm.addEventListener('submit', function (event) {
    event.preventDefault();
    
    const email = authEmail.value;
    const password = authPassword.value;

    if (isRegistering) {
        userData = { email, password };
        alert('Inscription réussie ! Vous pouvez maintenant vous connecter.');
        isRegistering = false;
        formTitle.textContent = 'Connexion';
        authForm.querySelector('button').textContent = "Se connecter";
        switchFormBtn.textContent = "S'inscrire";
        passwordStrength.classList.add('hidden');
        authForm.reset();
    } else {
        if (userData.email === email && userData.password === password) {
            window.location.href = 'bienvenue.html';
        } else {
            errorMessage.classList.remove('hidden');
        }
    }
});
